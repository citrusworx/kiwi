=== Forum REST API ===
Contributors: drewwinkles
Tags: forums, api, rest api
Requires at least: 5.0.0
Tested up to: 6.6.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A simple REST API to retrieve forum-related data, including forums, topics, and replies.

== Description ==
A plugin that allows the exposure of Forums to the REST API.
